//
//  ViewController.swift
//  DashCamVideo
//
//  Created by Jake Fumar on 3/31/19.
//  Copyright © 2019 Jake Fumar. All rights reserved.
//

import UIKit
import AVKit
import MobileCoreServices

//imports for accelerometer below
import UIKit
import CoreMotion



class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    //accelerometer code begins here:
    var motion = CMMotionManager()
    
    
    
    @IBOutlet weak var RecordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    
    func myAccelerometer(){
        
        motion.accelerometerUpdateInterval = 0.25
        motion.startAccelerometerUpdates(to: OperationQueue.current!) { (data, error) in
            print(data as Any)
            if let trueData = data {
                self.view.reloadInputViews()
                let x = trueData.acceleration.x
                let y = trueData.acceleration.y
                let z = trueData.acceleration.z
                let totalAcceleration = calculateMagnitude (no1:Float (x), no2: Float (y),no3: Float (z))
                
             
                
                if (Float(totalAcceleration) > 2.00){
                    let alert = UIAlertController (title: "Sudden acceleration detected", message: "Are you in an accident?", preferredStyle: .alert)
                    
                    alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: nil))
                    alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: nil))
                    
                    self.present(alert, animated: true)
                }//end of if float(totalAcceleration) statement
            } //this bracket closes the if let trueData statement
        }
    }


    @IBAction func RecordAction(_ sender: UIButton) {
        
        
        
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera){
           
            print("Camera Available")
            
            let imagePicker = UIImagePickerController()
            
            
            imagePicker.delegate = self
            imagePicker.sourceType = .camera;
            imagePicker.mediaTypes = [kUTTypeMovie as String]
            imagePicker.allowsEditing = false
            
            imagePicker.showsCameraControls = true
            
            
            self.present(imagePicker, animated: true, completion: nil)
            myAccelerometer()

        }
        
        else {
            
            ("Camera Unavailable")
        }
        
    }
    
    
}

func calculateMagnitude (no1: Float, no2: Float, no3: Float) -> Float {
    let a = no1
    let b = no2
    let c = no3
    var data: Float = 0.00
    
    data = ((a*a) + (b*b) + (c*c)).squareRoot()
    return data
}

